/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alumno
 */
public class Habitaciones {
    private Empleados []vectorHabitacion;
    int nroHabitacion;
    private int piso;
    private int capacidadMaxima;
    private Huespedes Huesped;

    public Habitaciones(int nroHabitacion, int piso, int capacidadMaxima, Huespedes Huesped) {
        this.piso = piso;
        this.capacidadMaxima = capacidadMaxima;
        this.Huesped = Huesped;
        this.nroHabitacion=0;
        int i;
        for(i=1;i<51;i++)
            vectorHabitacion[i]=null;
        this.Huesped=null;
    }
    
   public void setEmpleadoAHabitacion(Empleados E){
       vectorHabitacion[getNroHabitacion()]=E;
   }
   
   public String aCargo(int i){
       return(vectorHabitacion[i].getNombre());
   }

    public int getNroHabitacion() {
        return nroHabitacion;
    }

    public void setNroHabitacion(int nroHabitacion) {
        this.nroHabitacion = nroHabitacion;
    }
   
   

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public Huespedes getHuesped() {
        return Huesped;
    }

    public void setHuesped(Huespedes Huesped) {
        this.Huesped = Huesped;
    }
    public int obtenerHuespedMayorEstadia(){
        int max=-999;
        int i=1;
        Huespedes H=null;
        int dniHuesped=-1;
        while(i<51){
            if(getNroHabitacion()!=0){
                if(H.getDiasEstadia()>max){
                    max=H.getDiasEstadia();
                    dniHuesped=H.getDNI();
                }
            }
            i++;
        }
        return dniHuesped;
    }
    
}
