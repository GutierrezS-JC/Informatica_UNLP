/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alumno
 */
public class Empleados extends Persona{
    private int antiguedad;
    private Habitaciones [] vector;

    public Empleados(int antiguedad, Habitaciones[] vector, String nombre, int DNI, int edad) {
        super(nombre, DNI, edad);
        this.antiguedad = antiguedad;
        vector=new Habitaciones[10];
        int i;
        for(i=0;i<10;i++)
            vector[i]=null;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }
    
    public void asignarHabitacionAEmpleado(int i, Empleados E){
       vector[i].setEmpleadoAHabitacion(E);
        
    }

    public int getCantHabitacionesACargo(){
        int i=0;
        int j=1;
        int cant=0;
        while(i<10){
            while(j<51){
                if(vector[i].aCargo(i)==getNombre())
                cant++;
            j++;
            }        
        }
        return cant;
   }
    
    public int calcularDisponibilidad(int i){
        int cant=0;
        if((vector[i].nroHabitacion>-1)&&(vector[i].nroHabitacion<51)){
            if(vector[i].getHuesped()!=null)
                cant++;
    }
        return cant;
    }
    public String toString() {
        String aux=("El nombre del empleado es: "+ getNombre()+ " su antiguedad es: "+ getAntiguedad()+ " y la cantidad de habitaciones a cargo es: "+ getCantHabitacionesACargo());
        return aux;
    }
    

    
    
    
}
