/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alumno
 */
public class Huespedes extends Persona {
   private String nacionalidad;
   private int nroHabitacon;
   private int diasEstadia;

    public Huespedes(String nacionalidad, int nroHabitacon, int diasEstadia, String nombre, int DNI, int edad) {
        super(nombre, DNI, edad);
        this.nacionalidad = nacionalidad;
        this.nroHabitacon = nroHabitacon;
        this.diasEstadia = diasEstadia;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getNroHabitacon() {
        return nroHabitacon;
    }

    public void setNroHabitacon(int nroHabitacon) {
        this.nroHabitacon = nroHabitacon;
    }

    public int getDiasEstadia() {
        return diasEstadia;
    }

    public void setDiasEstadia(int diasEstadia) {
        this.diasEstadia = diasEstadia;
    }
    
    public String toString(){
        String aux=("El nombre del huesped es: "+ super.getNombre()+ "su DNI es: "+ super.getDNI()+" y su nacionalidad es: "+ getNacionalidad());
        return aux;
    }
   

    
    
    
}
